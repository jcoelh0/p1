import java.util.*;
import java.io.*;
public class ExemploAjuda {			
public static void main (String args[])     throws IOException
{	File source = new File("source.txt");
	if( verify(source,"source.txt") ) 	{   
		Scanner file_name = new Scanner(source);
		while ( file_name.hasNextInt() ) System.out.println( file_name.nextInt() );
		file_name.close();		}
		
		File summary = new File("summary.txt");
		PrintWriter pwr = new PrintWriter(summary); 
		save_results(pwr,null,0); 
		pwr.close();
}

static boolean verify(File my_file, String nameIn)
{  if (!my_file.exists())                 {
		System.out.println("ERROR: input file " + nameIn + " does not exist!");		return false;        }
  if (my_file.isDirectory())         {
		System.out.println("ERROR: input file " + nameIn + " is a directory!");		return false;        }
  if (!my_file.canRead())          {
		System.out.println("ERROR: cannot read from input file " + nameIn+ "!");	return false;        }
   return true; 			}

static void save_results(PrintWriter pw,int[] notas,int N)
{
	pw.printf(	"Número de alunos:	%2d\n"+
				"Nota máxima:     	%2d\n"+
				"Nota mínima:     	%2d\n"+
				"Nota média:     	%4.1f\n"+
				"Alunos aprovados	%2d\n"+
				"Alunos reprovados	%2d\n"+
				"Média (aprovados)	%4.1f\n",N,max(notas),min(notas),media(notas),
										     aprovados(notas),reprovados(notas),
											 media_aprovados(notas));	
}

static double media(int[] a)
{	return 0;	}

static int min(int[] a)
{	return 0;	}

static int max(int[] a)
{	return 0;	}

static int aprovados(int[] a)
{	return 0;	}

static double media_aprovados(int[] a)
{	return 0;}

static int reprovados(int[] a)			
{	return 0;	}

}
class aluno											// declaration of the class aluno
{	int nm; 
	String nome; 
	int nota;	}
