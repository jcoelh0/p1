import java.util.*;
import java.io.*;
public class CriarFicheiroInicial {	
	static Random rand = new Random();			
public static void main (String args[])     throws IOException
{	int N = rand.nextInt(10)+10;
	String[] ArrayFirstNames = {"HENRIQUE","FILIPE","ALEXANDRE","EMANUEL","FRANCISCO","BRUNO",
								"MARIA","ISABEL","PAULO","JOANA","DANIELA","ANA","RUI","CATARINA",
								"DIOGO","DANIEL","RODRIGO","TIAGO","HELENA","RICARDO","ARNALDO"};
	String[] ArraySecondNames ={"CHAVES","CARDOSO","OLIVEIRA","SOARES","COSTA","MARQUES",
								"BARBOSA","RAMOS","PEREIRA","PEDRO","FERNANDES","COELHO","PIRES","HENRIQUES",
								"SANTOS","RODRIGUES","CARVALHO","PEREIRA","SILVA","MATOS","CORREIA"};
	int[] nm = new int[N],nmt = new int[N],nota_m = new int[N]; 
	boolean flag;
	String[] name = new String[N];
    File source = new File("source.txt");
    File sourceN = new File("sourceN.txt");
    PrintWriter pws = new PrintWriter(source);
    PrintWriter pwn = new PrintWriter(sourceN);
    do {
		flag = false;
		for(int i = 0; i < N;  i++)	
		{	nm[i] = 80000+rand.nextInt(1000);
			nmt[i] = nm[i];		} 
		Arrays.sort(nmt);
		for(int i = 0; i < N-1;  i++)
			if(nmt[i] != nmt[i+1]) continue;
			else flag = true;
		} while(flag);	
    for(int i = 0; i < N;  i++)
    {	
		pws.printf("%5d     %2d\n",nm[i],rand.nextInt(20));
		pwn.printf("%5d     %-15s\n",nmt[i],ArrayFirstNames[rand.nextInt(20)]+ " " + ArraySecondNames[rand.nextInt(20)]);
	}
		pws.close();
		pwn.close();
		
		File summary = new File("summary.txt");
		PrintWriter pwr = new PrintWriter(summary);  
		pwr.printf("Número de alunos:	%2d\n"+
					"Nota máxima:     	%2d\n"+
					"Nota mínima:     	%2d\n"+
					"Nota média:     	%4.1f\n"+
					"Alunos aprovados	%2d\n"+
					"Alunos reprovados	%2d\n",0,0,0,0.0,0,0);
		pwr.close();
}
}
