
import java.util.Scanner;
/*
* Created by jam on 2-nov-2015
* folha 7 exercicio 6
* implementação final da função main
*/

public class f7e6_3 {
// Scanner para leitura de dados do teclado
    static Scanner ler = new Scanner(System.in);
    public static void main(String[] args) {
        int dia,ndias;

        System.out.println("Introduza as temperaturas:\nNuemro de dias: ");
        ndias=ler.nextInt();
        TempDia[] d=new TempDia[ndias];
        for (int i=0; i<ndias; i++) d[i]= LerTemp();
        // System.out.printf("e1\n");
        dia = AmplitudeMax(d);
        System.out.printf("Amplitude termica dia 1 = %4.1f\n",d[0].aTermica);
        System.out.printf("Amplitude termica dia %2d = %4.1f\n",dia+1, d[dia].aTermica);
    }
    public static TempDia LerTemp () {
        TempDia t = new TempDia();
        do {
            System.out.printf("Temperatura minima (-20): ");
            t.tMin=ler.nextFloat();
        } while (t.tMin < -20 || t.tMin > 50);
        do {
            System.out.printf("Temperatura maxima (50): ");
            t.tMax=ler.nextFloat();
        } while (t.tMax < t.tMin || t.tMax > 50);
        t.aTermica = t.tMax-t.tMin;
        return t;
    }
    public static int AmplitudeMax(TempDia[] td) {
        int dia = 0;
        float aTermicaMax=td[0].aTermica;
        for (int n=0; n<td.length; n++) {
            if (td[n].aTermica > aTermicaMax) {
                aTermicaMax=td[n].aTermica;
                dia = n;
            }  
        }
        return  dia;
    }
}
class TempDia {
    float tMin;
    float tMax;
    float aTermica;
}
