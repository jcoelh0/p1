
import java.util.Scanner;
/*
* Created by jam on 2-nov-2015
* folha 7 exercicio 6
* implementação e teste da função 2
*/

public class f7e6_2 {
// Scanner para leitura de dados do teclado
    static Scanner ler = new Scanner(System.in);
    public static void main(String[] args) {
        int dia;
        TempDia[] d=new TempDia[3];
        System.out.println("Introduza as temperaturas:");
        d[0]= LerTemp();
        d[1]= LerTemp();
        d[2]= LerTemp();
        dia = AmplitudeMax(d);
        System.out.printf("Amplitude termica dia 1 = %4.1f\n",d[0].aTermica);
        System.out.printf("Amplitude termica dia %2d = %4.1f\n",dia+1, d[dia].aTermica);
    }
    public static TempDia LerTemp () {
        TempDia t = new TempDia();
        do {
            System.out.printf("Temperatura minima (-20): ");
            t.tMin=ler.nextFloat();
        } while (t.tMin < -20 || t.tMin > 50);
        do {
            System.out.printf("Temperatura maxima (50): ");
            t.tMax=ler.nextFloat();
        } while (t.tMax < t.tMin || t.tMax > 50);
        t.aTermica = t.tMax-t.tMin;
        return t;
    }
    public static int AmplitudeMax(TempDia[] td) {
        int dia = 0;
        float aTermicaMax=td[0].aTermica;
        for (int n=0; n<td.length; n++) {
            if (td[n].aTermica > aTermicaMax) {
                aTermicaMax=td[n].aTermica;
                dia = n;
            }  
        }
        return  dia;
    }
}
class TempDia {
    float tMin;
    float tMax;
    float aTermica;

}
