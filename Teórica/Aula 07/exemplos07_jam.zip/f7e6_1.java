
import java.util.Scanner;
/*
* Created by jam on 2-nov-2015
* folha 7 exercicio 6
*
*/

public class f7e6_1{
// Scanner para leitura de dados do teclado
    static Scanner ler = new Scanner(System.in);
    public static void main(String[] args) {
        TempDia d;
        System.out.println("Introduza as temperaturas:");
        d= LerTemp();

        System.out.printf("Amplitude termica= %4.1f\n",d.aTermica);
    }
    public static TempDia LerTemp () {
        TempDia t = new TempDia();
        do {
            System.out.printf("Temperatura minima (-20): ");
            t.tMin=ler.nextFloat();
        } while (t.tMin < -20 || t.tMin > 50);
        do {
            System.out.printf("Temperatura maxima (50): ");
            t.tMax=ler.nextFloat();
        } while (t.tMax < t.tMin || t.tMax > 50);
        t.aTermica = t.tMax-t.tMin;
        return t;
    }
}
class TempDia {
    float tMin;
    float tMax;
    float aTermica;
}
