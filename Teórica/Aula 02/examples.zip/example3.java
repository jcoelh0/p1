import java.util.Scanner;
public class example3{
  public static void main(String[] args){
    Scanner kb = new Scanner(System.in);

	double t, p, nota;
	
	t = kb.nextDouble();
	p = kb.nextDouble();
	
	nota = (t + p) / 2;
	
	if(nota >= 9.5) 
	{
		System.out.print("Aprovado com ");
	}
	else
	{
		System.out.print("Reprovado com ");
    }
	if(p >= 9.5)
	{
		System.out.println(" nota prática positiva");
	}
	else
	{
		System.out.println(" nota prática negativa");
	}
	}
}
