import java.util.Scanner;
public class example1{
  public static void main(String[] args){
    Scanner kb = new Scanner(System.in);

	int x, y;
	
	x = kb.nextInt();
	y = kb.nextInt();
	boolean b = (x > y);
	
	if(b) 
	{
		System.out.println(" x > y ");
		System.out.println("Verdadeira");
	}
	else
	{
		System.out.println(" x > y ");
		System.out.println("Falsa");
	}
	
	System.out.println("Ultima linha do programa");

    }
}
