import java.util.Scanner;
public class example2{
  public static void main(String[] args){
    Scanner kb = new Scanner(System.in);

	int x, y;
	
	x = kb.nextInt();
	y = kb.nextInt();
	
	if(x > y) 
	{
		System.out.println(" x > y ");
		System.out.println("Primeira Verdadeira");
	}
	else if(x < y)
	{
		System.out.println(" x < y ");
		System.out.println("segunda verdadeira");
	}
	else
	{
		System.out.println(" x == y ");
		System.out.println("ambas falsas");
	}
	
	System.out.println("Ultima linha do programa");

    }
}
