import java.util.Scanner;
public class exemplo3{
  public static void main(String[] args){
    Scanner kb = new Scanner(System.in);
    
    int dia;
    System.out.print("Dia (numero 1 e 7): ");
    dia = kb.nextInt();
    
    switch(dia){
      case 1: System.out.println("Segunda");
      case 2: System.out.println("Terça");
      case 3: System.out.println("Quarta");
      case 4: System.out.println("Quinta");
      case 5: System.out.println("Sexta");
      case 6: System.out.println("Sabado");
      case 7: System.out.println("Domingo");
      
    }
  }
}  
