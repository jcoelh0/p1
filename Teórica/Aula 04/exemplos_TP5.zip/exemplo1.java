import java.util.Scanner;

// Impressão dos numeros inteiros de 1 a 10 e calculo da sua soma
// Exemplo com while, do..while e for

public class exemplo1
{
  public static void main(String[] args)
  {        
	  Scanner sc = new Scanner(System.in);
	  int n, soma;
	  
	  soma = 0;
	  n = 1;
	  while(n <= 10)
	  {
		  System.out.println(n);
		  soma += n;
		  n++;
	  }
	System.out.println("soma (1) = " + soma);
	  
	soma = 0;
	n = 1;
	do
	{
		System.out.println(n);
		soma += n; 
		n++;
	}while(n <= 10);
	
    System.out.println("soma (2) = " + soma);
    
    soma = 0;
    for(n = 1 ; n <= 10 ; n++)
    {
		System.out.println(n);
		soma += n;
	}
	System.out.println("soma (3) = " + soma);
  }
}
