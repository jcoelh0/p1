import java.util.Scanner;

// Escrita de 10 letras minúsculas de forma aleatória

public class letras
{
  public static void main(String[] args)
  {        
    char letra;
    
    for(int i = 0 ; i < 26 ; i++)
    {
		letra = (char)('a' + 26 * Math.random());
		System.out.println(letra);
	}
  }
}
