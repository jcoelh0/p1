import java.util.Scanner;

// Soma de valores reais até aparecer numero negativo
// leitura termina também quando a soma ultrapassa o valor 100 (break)

public class exemplo3
{
  public static void main(String[] args)
  {        
	  Scanner sc = new Scanner(System.in);
	double n, soma = 0.0;
	
	do
	{
		System.out.print("Valor real: ");
		n = sc.nextDouble();
		
		if(n > 0.0)
		{
			soma += n;
		}
		
		if(soma > 100)
			break;
			
	}while(n >= 0.0);
		
	System.out.println("soma = " + soma);
  }
}
