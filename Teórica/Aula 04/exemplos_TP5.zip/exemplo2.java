import java.util.Scanner;

// Soma de todos os pares entre 0 e n, com n pedido ao utilizador
// solução com incrementos de 2 a 2
// solução com avaliação do resto da divisão inteira
// solução com continue

public class exemplo2
{
  public static void main(String[] args)
  {        
	  Scanner sc = new Scanner(System.in);
	int n, soma = 0;
	
	do
	{
		System.out.print("n: ");
		n = sc.nextInt();
	}while(n < 0);
	
	for(int x = 0 ; x >= 0 && x <= n ; x += 2)
	{
		System.out.println(x);
		soma += x;
	}
	System.out.println("Soma (1) = " + soma);
	
	soma = 0;
	for(int x = 0 ; x <= n ; x++)
	{
		if(x % 2 == 0)
		{
			System.out.println(x);
			soma += x;
		}
	}
	System.out.println("Soma (2) = " + soma);
	
	soma = 0;
	for(int x = 0 ; x <= n ; x++) //percorre todos
	{
		if(x % 2 == 1)
			continue;
		
		System.out.println(x);
		soma += x;
		
	}
	System.out.println("Soma (3) = " + soma);
	
	soma = 0;
	for(int x = n ; x >= 0 ; x--) //percorre todos ao contrario
	{
		if(x % 2 == 1)
			continue; // não executa o resto do ciclo e passa à iteração seguinte
		
		System.out.println(x);
		soma += x;
		
	}
	System.out.println("Soma (4) = " + soma);
	
		
  }
}
