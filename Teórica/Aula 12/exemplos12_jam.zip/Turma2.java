import java.util.Scanner;
import java.io.*;

/* Revisão sobre arrays e introdução aos ficheiros texto.
 * Interação com o utilizador utilizando um menu.
*/
public class Turma2 {
    static Scanner kb = new Scanner(System.in);
    public static void main(String[] args) throws IOException{
        int op, oc;
        Aluno[] t = new Aluno[100];
        int[] id = new int[100];
        int[] inum = new int[100];
        int[] inome = new int[100];
        int[] it2 = new int[100];
        int n = 0; // começamos considerando o array vazio
        boolean Indexado = false;
        do{
            // mostrar opcoes
            System.out.print("\n1- Ler Ficheiro \n2- Listar Alunos e Notas Finais "
            + "\n3- Escrever Ficheiro \n4- Listagens Ordenadas "
            + "\n5- Ordenar \n6- Acrescentar alunos (teclado) "
            + "\n7- Alterar Aluno "
            + "\n0- FIM \nOpcao ->");
            op = kb.nextInt();
            switch (op) {
            case 1: // Ler ficheiro
                System.out.print("Le Ficheiro (1- novo; 2- Acrescenta): ");
                int novo = kb.nextInt();
                if (novo == 1) n=0; // Inicializa array com 0 elementos, senão acrescenta
                n = lerFich(t,n);
                Indexado=false;
                break;
            case 2: // Lista alunos e notas finais
                escrever(t, n,id);
                break;
            case 3: // Escreve ficheiro
                System.out.print("Escreve ordenado por [1-nome, 2-numero, 3- teste 2]: ");
                oc= kb.nextInt();
                if (oc == 1)escreverFich(t, n,inome);
                if (oc == 2)escreverFich(t, n,inum);
                if (oc == 3)escreverFich(t, n,it2);
                break;
            case 4: // Lista ordenada por vários campos
                System.out.print("Lista ordenada por [1-nome, 2-numero, 3- teste 2]: ");
                oc= kb.nextInt();
                if (oc == 1)escrever(t, n,inome);
                if (oc == 2)escrever(t, n,inum);
                if (oc == 3)escrever(t, n,it2);
                break;
            case 5: // ordenação sem índices, reordena todo o array de alunos
                System.out.print("Ordenar [1-nome, 2-numero]: ");
                int nuno = kb.nextInt();
                bubbleSort(t, n, nuno);
                break;
            case 6: // adiciona alunos do teclado
                n = appendTec(t,n);
                Indexado=false;
                break;
            case 7: // alterar registo
                alterarAluno(t,n);
                Indexado=false;
                break;
            case 0:
                System.out.println("fim do programa");
                break;
            default:
                System.out.println("Opção invalida!");
            }
            if (!Indexado){ // cria os vários índice depois de uma alteração no array de alunos
                id = new int[n];
                for (int j=0; j<n; j++)id[j]=j; // cria indice por ordem de entrada
                inum  = bubbleSort4(t,n,2); //cria indice por numero
                inome = bubbleSort4(t,n,1); //cria indice por nome
                it2 = bubbleSort4(t,n,3); //cria indice por t2 - decrescente
                Indexado = true;
            }
        } while(op != 0); // termina o programa com a opção 10

    }

    public static void escrever(Aluno a[], int nElem, int[] ind) {
        System.out.printf("\nNum   Nome           T1    T2    Final\n");
        for(int i = 0 ; i < nElem ; i++) { // percorremos todos os elementos armazenados no array
            System.out.printf("%-4d %-15s %4.1f  %4.1f  %4.1f\n", a[ind[i]].num,a[ind[i]].nome,
                              a[ind[i]].t1,a[ind[i]].t2,(a[ind[i]].t1+a[ind[i]].t2)/2.);
        }
    }

    public static void escreverFich(Aluno a[], int nElem, int[] ind) throws IOException {
        // Acesso a ficheiros para escrita: String -> File -> PrintWriter
        String nome = new String();
        System.out.print("Nome do ficheiro escrita: ");
        do {
            nome = kb.nextLine();
        } while(nome.length() == 0);
        File f = new File(nome);
        PrintWriter pw = new PrintWriter(f);

        for(int i = 0 ; i < nElem ; i++) {
            pw.printf("%4d %-15s  %4.1f   %4.1f\n", a[ind[i]].num,
            a[ind[i]].nome, a[ind[i]].t1, a[ind[i]].t2);
        }
        pw.close();
    }

    public static int lerFich(Aluno a[], int nElem)throws IOException {
        // Acesso a ficheiros para leitura: String -> File -> Scanner
        int pos = nElem;
        String nome = new String();
        System.out.print("Nome do ficheiro leitura: ");
        do {
            nome = kb.nextLine();
        } while(nome.length() == 0);
        File f = new File(nome);
        Scanner sc = new Scanner(f);
        while(sc.hasNext()) { // enquanto houver valores para ler
            a[pos] = new Aluno();
            a[pos].num = sc.nextInt(); // numero
            a[pos].nome="";
            while (!sc.hasNextDouble())
                a[pos].nome += ' '+sc.next(); // lê várias palavras do nome
            a[pos].t1 = sc.nextDouble();
            a[pos].t2 = sc.nextDouble();
            pos++;
        }
        sc.close();
        return pos;
    }
    // adicionar registos de alunos aos existentes - a partir do teclado
    public static int appendTec(Aluno a[], int nElem) {
        int pos =nElem;
        System.out.printf("Introduza dados do aluno (Num(-1 fim) Nome T1 T2): ");
        do { // enquanto houver valores para ler
            a[pos] = new Aluno();
            a[pos].num = kb.nextInt(); // numero
            if ( a[pos].num > 0) {
                a[pos].nome="";
                while (!kb.hasNextDouble())
                    a[pos].nome += ' '+kb.next(); // lê várias palavras do nome
                a[pos].t1 = kb.nextDouble();
                a[pos].t2 = kb.nextDouble();
            }
        } while(a[pos++].num > 0 && pos < a.length);
        return --pos;
    }
    // alterar os dados de um aluno existente: nome, t1 e t2
    public static void alterarAluno(Aluno a[], int nElem) {
        int pos = -1,n=0;
        int nAluno;
        System.out.printf("Numero Aluno a Alterar: ");
        nAluno=kb.nextInt();
        do { // ve se aluno existe
            if(a[n++].num == nAluno) {
                pos = n-1;
            }
        } while(pos == -1 && n <nElem);
        if (pos >= 0 ) {
            System.out.printf("Introduza dados do aluno [Nome, t1, t2]: ");
            a[pos].nome="";
            while (!kb.hasNextDouble())
                a[pos].nome += ' '+kb.next(); // lê várias palavras do nome
            a[pos].t1 = kb.nextDouble();
            a[pos].t2 = kb.nextDouble();

        } else {
            System.out.printf("Aluno NAO EXISTE\n");
        }

        return;
    }
    // ordena array de  Classe Aluno
// 2º parâmetro campo =1 ordena pelo nome; = 2 ordena pelo nº
    public static void bubbleSort(Aluno a[], int nAlunos, int campo) {
        int t = 0;

        do {
            t = 0;
            for(int i = 0 ; i <= nAlunos- 2; i++) {
                switch (campo) {
                case 1:
                    if(a[i].nome.compareToIgnoreCase(a[i+1].nome) > 0) {
                        swap(a, i, i+1);
                        t++;
                    }
                    break;
                case 2:
                    if(a[i].num > a[i+1].num) {
                        swap(a, i, i+1);
                        t++;
                    }
                    break;
                }
            }
        } while(t != 0);
    }

    public static void swap(Aluno a[], int i, int j) {
        Aluno tmp = new Aluno();
        tmp = a[i];
        a[i] = a[j];
        a[j] = tmp;
    }
// fim - ordenação Classe Aluno
    public static void swap(int a[], int i, int j) {
        int tmp;
        tmp = a[i];
        a[i] = a[j];
        a[j] = tmp;
    }
// ordenação - retorna índice ordenado
// 2º parâmetro campo =1 ordena pelo nome; = 2 ordena pelo nº; = 3 pelo t2 decres.
    public static int[] bubbleSort4(Aluno a[], int nAlunos, int campo) {
        int[] ord = new int [nAlunos];
        for (int i=0; i<ord.length; i++)ord[i]=i;
        int t = 0;

        do {
            t = 0;
            for(int i = 0 ; i <= nAlunos- 2; i++) {
                switch (campo) {
                case 1: // ordena pelo nome - crescente
                    if(a[ord[i]].nome.compareToIgnoreCase(a[ord[i+1]].nome) > 0) {
                        swap(ord, i, i+1);
                        t++;
                    }
                    break;
                case 2: // ordena pelo numero - crescente
                    if(a[ord[i]].num > a[ord[i+1]].num) {
                        swap(ord, i, i+1);
                        t++;
                    }
                    break;
                case 3: // ordena pelo teste 2 - decrescente
                    if(a[ord[i]].t2 < a[ord[i+1]].t2) {
                        swap(ord, i, i+1);
                        t++;
                    }
                    break;
                }
            }
        } while(t != 0);
        return ord;
    }

}
class Aluno {
    int num;
    String nome;
    double t1,t2;
}
