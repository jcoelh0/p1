
/**
 * Created by jam on 01-Jul-15.
 */
import processing.core.*;
import java.util.*;

public class PBatalhaNaval1 extends PApplet {

    int LADO = 100;
    int LINHAS = 5, COLUNAS = 5;
    int tiro = 11;
    int[][] tabuleiro = new int[LINHAS][COLUNAS];
    Random generator = new Random();

    public static void main(String args[]) {
        PApplet.main("PBatalhaNaval1");
    }

    public void settings() {
        size(500, 500);
    }

    public void setup() {
        noStroke();
        // coloca barcos aleatoriamente
        for (int b = 0; b < 3; b++) {
            int nextl = generator.nextInt(5);
            int nextc = generator.nextInt(5);
            tabuleiro[nextl][nextc] = 1;
        }
    }

    public void draw() {
        background(0, 255, 0);
        // desenha tabuleiro
        for (int l = 0; l < LINHAS; l++) {
            for (int c = 0; c < COLUNAS; c++) {
                fill(255, 0, 0);
                if (tabuleiro[l][c] < 0) {
                    fill(0, 0, 255);
                }
                rect(c * LADO, l * LADO, LADO - 5, LADO - 5);
            }
        }
    }

    public void mousePressed() {
        int l, c;
        c = mouseX / LADO;
        l = mouseY / LADO;
        if (tabuleiro[l][c] > 0) {
            tabuleiro[l][c] = -tabuleiro[l][c];
        }
    }

}
