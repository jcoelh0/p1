
import java.util.Scanner;
/*
 * Created by jam on 26-out-2015
 * Ler id do aluno, estado, notas de uma turma e calcular nota final
 * Aluno é um tipo composto (classe) : id aluno, t1,t2,nota final, estado
 */

public class TurmaClasse {

    public static void main(String[] args) {
        // Scanner para leitura de dados do teclado
        Scanner ler = new Scanner(System.in);
        final int NALUNOS = 10;
        // int[][] turma= new int[NALUNOS][5];
        Aluno[] turma = new Aluno[NALUNOS];
        int id, num = 0;

        System.out.println("Introduza as notas dos alunos (ID = 0 termina):");
        System.out.printf("ID do aluno: ");
        id = ler.nextInt();
        while (id > 0) {
            turma[num] = new Aluno();
            turma[num].id = id;
            System.out.printf("Nota T1: ");
            turma[num].t1 = ler.nextFloat();
            System.out.printf("Nota T2: ");
            turma[num].t2 = ler.nextFloat();
            System.out.printf("estado (true/false):");
            turma[num].estado = ler.nextBoolean();
            turma[num].notaf =(int) ((turma[num].t1+ turma[num].t2)/2+.5);
            num = num + 1;
            System.out.printf("ID do aluno: ");
            id = ler.nextInt();
        }
        System.out.println("_ID_NF___T1___T2");
        for (int a = 0; a < num; a++) {
            System.out.printf("%3d%3d%5.1f%5.1f %6b\n", turma[a].id, turma[a].notaf, turma[a].t1, turma[a].t2, turma[a].estado);

        }
    }

}

class Aluno {
    int id;
    boolean estado;
    float t1;
    float t2;
    int notaf;
}
