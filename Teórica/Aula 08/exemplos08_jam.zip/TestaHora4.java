import java.util.Scanner;

public class TestaHora4 {
    static final Scanner ler = new Scanner(System.in);

    public static void main(String[] args) {
        Hora inicio;  // tem de definir o novo tipo Hora!
        Hora fim;

        inicio = new Hora();
        inicio.h = 9;
        inicio.m = 23;
        inicio.s = 5;
        //~ fim = inicio;
        System.out.print("Começou às ");
        printHora(inicio);  // crie esta função!
        System.out.printf("\nQuando termina?\n");
        fim = lerHora();  // crie esta função!
        System.out.printf("%-10s","Início: ");
        printHora(inicio);
        System.out.printf("\n%-10s","Fim: ");
        printHora(fim);
    }
    public static void printHora(Hora h) {
        System.out.printf("%02d:%02d:%02d",h.h,h.m,h.s);
    }
    public static Hora lerHora() {
        Hora t = new Hora();
        // validar as leituras
        do {
            System.out.printf("Hora[0:23]: ");
            t.h=ler.nextInt();
        } while(t.h <0 || t.h >23);
        t.m=ler.nextInt();
        t.s=ler.nextInt();
        return t;
    }
}
class Hora {
    int h, m, s;
}
/**
EXEMPLO do pretendido:
$ java TestaHora
Começou às 09:23:05.
Quando termina?
horas? 11
minutos? 72
minutos? 7
segundos? 2
Início: 09:23:05 Fim: 11:07:02.
**/
