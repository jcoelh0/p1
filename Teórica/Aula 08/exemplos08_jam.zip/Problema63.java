import java.util.Scanner;

public class Problema63 {
    static final Scanner ler = new Scanner(System.in);

    public static void main(String[] args) {
    int x;
    int a[] = new int[50];
    int b[];//={1,1};
    do
    {
        x=ler.nextInt();
        
        switch(x)
        {
            case 1:
            b = lerseq(a);
            break;
            case 2:
            escreverseq(b);
            break;
            
        }
        
    }while(x!=10);
  
  
      
    }
    public static int[] lerseq(int a[])
    {
        int i;
        for(i=0; i<a.length; i++)
        {
            System.out.print("a[" + i + "] = ");
            a[i] = ler.nextInt();
            if(a[i]==0) break;
        }
        int b[] = new int[i];
        for(int j=0; j<i; j++) b[j] = a[j];
        return b;
    }
    public static void escreverseq(int a[])
    {
        for(int i =0; i<a.length;i++)
        System.out.printf("a[%d] = %d\n",i,a[i]);
    }
}
