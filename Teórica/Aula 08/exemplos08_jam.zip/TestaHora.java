import java.util.Scanner;

public class TestaHora {
    static final Scanner ler = new Scanner(System.in);

    public static void main(String[] args) {
        Hora inicio;  // tem de definir o novo tipo Hora!
        Hora fim;

        inicio = new Hora();
        inicio.h = 9;
        inicio.m = 23;
        inicio.s = 5;
        fim=inicio; // para testar
        System.out.print("Começou às ");
        printHora(inicio);  // crie esta função!
        System.out.println(".");
        System.out.println("Quando termina?");
        fim = lerHora();  // crie esta função!
        System.out.printf("\n%-12s","Início: ");
        printHora(inicio);
        System.out.printf("\n%-12s"," Fim: ");
        printHora(fim);
    }
    public static Hora lerHora() {
        Hora h = new Hora();
        do {
            System.out.printf("Introduza Hora[0:23]:");
            h.h=ler.nextInt();
        }while(h.h < 0 || h.h >23);
        do {
            System.out.printf("Introduza minutos[0:59]:");
            h.m=ler.nextInt();
        }while(h.m < 0 || h.m >59);
        do {
            System.out.printf("Introduza segundos[0:59]:");
            h.s=ler.nextInt();
        }while(h.s < 0 || h.s >59);
    
        return h;
    }
    public static void printHora(Hora t) {
        System.out.printf("%02d:%02d:%02d",t.h,t.m,t.s);
    }
}
class Hora {
    int h, m, s;
}
/**
EXEMPLO do pretendido:
$ java TestaHora
Começou às 09:23:05.
Quando termina?
horas? 11
minutos? 72
minutos? 7
segundos? 2
Início: 09:23:05 Fim: 11:07:02.
**/
