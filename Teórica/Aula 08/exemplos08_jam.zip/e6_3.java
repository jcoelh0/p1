import java.util.*;

public class e6_3 {

    static Scanner read = new Scanner(System.in);

    public static void main (String args[]) {
        int op = 0, num_array[] = null;
        do {
            op = printMenu();
            if (num_array == null && op != 1) {
                System.out.println("Array esta vasia");
                continue;
            }
            switch(op) {
            case 1:
                num_array = readSeq();
                System.out.printf("Tamanho de array = %d", num_array.length);
                break;
            case 2:
                printSeq(num_array);
                break;
            case 3:
                System.out.printf("Maximo: %d", printMax(num_array));
                break;
            case 4:
                System.out.printf("Minimo: %d", printMin(num_array));
                break;
            case 5:
                System.out.printf("Media: %f", printMed(num_array) );
                break;
            case 6:
                printIfEven(num_array);
                break;
            case 7:
                imprimirDados(gravarDados(num_array));
                break;
            case 8:
                System.out.printf("Desvio padrao: %f", standard_deviation(num_array));
                break;
            case 9:
                ocorre_maior_que_1(num_array);
                break;
            }
        } while(op != 10);
        System.out.println("O programa vai terminar...");
    }

    public static int printMenu() {
        System.out.println("\nAnalise de uma sequencia de numeros inteiros");
        System.out.println(" 1 - Ler a sequencia");
        System.out.println(" 2 - Escrever a sequencia");
        System.out.println(" 3 - Calcular o maximo da sequencia");
        System.out.println(" 4 - Calcular o minimo da sequencia");
        System.out.println(" 5 - Calcular a media da sequencia");
        System.out.println(" 6 - Detetar se e uma sequencia so constituida por numeros pares");
        System.out.println(" 7 - Imprimir sumario");
        System.out.println(" 8 - Desvio padrao");
        System.out.println(" 9 - Ocorre (> 1)");
        System.out.println(" 10 - Terminar o programa");
        System.out.print("Opcao -> ");
        int op = 0;
        do {
            op = read.nextInt();
            if(op < 1 || op > 10) System.out.print("Opcao invalida!\nOpcao -> ");
        } while(op < 1 || op > 10);
        return op;
    }

    public static int[] readSeq() {
        int[] num_array = new int[50];
        int n = 0, tmp;
        do {
            System.out.println("Insira valores:");
            System.out.printf("Valor[%d]: ", n);
            tmp = read.nextInt();
            if(tmp > 0) num_array[n++] = tmp;
            else if(tmp < 0) System.out.println("Valor invalido!");
        } while(tmp != 0 && n < 50);
        int[] array_final = new int[n];
        for(int j = 0; j < array_final.length; j++) array_final[j] = num_array[j];
        return array_final;

    }

    public static void printSeq(int[] num_array) {
        for(int j = 0; j < num_array.length; j++) System.out.print(" " + num_array[j] + " ");
    }

    public static int printMax(int[] num_array) {
        int tmp=0;
        for(int j = 0; j < num_array.length; j++)
            if(num_array[j] > tmp) tmp = num_array[j];
        return tmp;
    }

    public static int printMin(int[] num_array) {
        int tmp=num_array[0];
        for(int j = 0; j < num_array.length; j++)
            if(num_array[j] < tmp) tmp = num_array[j];
        return tmp;
    }

    public static double printMed(int[] num_array) {
        int j;
        double tmp = 0;
        for(j = 0; j < num_array.length; j++)
            if(num_array[j] > 0) tmp += (double)num_array[j];
        return tmp/j;
    }

    public static double printMed(double[] num_array) {
        int j;
        double tmp = 0;
        for(j = 0; j < num_array.length; j++)
            if(num_array[j] > 0) tmp += num_array[j];
        return tmp/j;
    }

    public static void printIfEven(int[] num_array) {
        int j=0;
        boolean onlyEven = true;
        for(j = 0; j < num_array.length; j++)
            if(num_array[j]%2 != 0) onlyEven = false;
        if(onlyEven) System.out.println("Sao todos pares");
        else System.out.println("Existem impares");
    }

    static dados gravarDados(int[] ar)				{
        dados d = new dados();
        d.maximo = printMax(ar);
        d.minimo = printMin(ar);
        d.media  = printMed(ar);
        return d;
    }

    static void imprimirDados(dados dd)				{
        System.out.printf("Maximo: %d\n", dd.maximo);
        System.out.printf("Minimo: %d\n", dd.minimo);
        System.out.printf("Media: %f\n", dd.media);
    }

    static double standard_deviation(int[] ar)				{
        double media = printMed(ar);
        //System.out.printf("M = %f\n", media);
        double[] ad = new double[ar.length];
        for (int i = 0; i < ar.length; i++) ad[i] = Math.pow(ar[i] - media,2);
        double media_ad = printMed(ad);
        return Math.sqrt(media_ad);
    }

    static void ocorre_maior_que_1 (int[] array) {
        int count;
        for(int i=0; i<array.length; i++) {
            count = 0;
            for(int j=0; (j<array.length) && (( (array[i] == array[j]) && (j<i) ) == false); j++)
                if (array[i] == array[j]) count++;
            if (count > 1) System.out.println(array[i]+" ocorre "+count+" vezes");
        }
    }
}

class dados	{
    int 	maximo, minimo;
    double 	media;
}

