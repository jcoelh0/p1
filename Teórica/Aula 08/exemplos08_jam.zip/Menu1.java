import java.util.Scanner;

public class Menu1 {
    static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int op, nval=0;
        int sequencia[]=new int[50];
        do {
            op=menu();
            switch(op) {
            case 1:
                nval = lerseq(sequencia);
                System.out.printf("%d\n", nval);
                break;
            case 2:
                imprimirseq(sequencia,nval);
                break;
            case 3:
                System.out.printf("%d\n", op);
                break;
            case 4:
                System.out.printf("%d\n", op);
                break;
            case 5:
                System.out.printf("Média = %5.2f\n", media(sequencia,nval));
                break;
            case 6:
                System.out.printf("%d\n", op);
                break;
            case 10:
                System.out.printf("%d\n", op);
                break;
            default:
                System.out.printf("Valor inválido\n");
            }
            //~ System.out.printf("%d\n", op);
        } while(op!=10);
    }
    public static int menu() {
        int op1;
        System.out.println("1-Ler a sequência");
        System.out.println("2-Escrever a sequência");
        System.out.println("3-Encontrar o máximo");
        System.out.println("4-Encontrar o minimo");
        System.out.println("5-Calcular a média");
        System.out.println("6-Detetar se é par");
        System.out.println("10-Terminar o programa");
        System.out.print("Opção -> ");
        op1=sc.nextInt();
        return op1;
    }
    public static int lerseq(int seq []) {

        int i;
        int e=0;
        do {
            System.out.print("Introduzir valor: ");
            i=sc.nextInt();
            if(i!=0) {
                seq[e]=i;
                e++;
            }
        } while (i!=0 && e<50);
        return e;

    }
    
    public static void imprimirseq(int seq[],int n) {
        int i=0;
        for (i=0; i<n; i++){
            System.out.printf("Nota %d:%d\n",i+1,seq[i]);
        }
    }
    public static double media(int seq [], int n) {
        int soma=0;
        for(int i=0;i<n;i++){
            soma=soma+seq[i];
        }
        return (double) soma/n;
    }
}
