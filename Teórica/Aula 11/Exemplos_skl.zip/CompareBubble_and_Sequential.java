import java.util.*;
public class CompareBubble_and_Sequential {	
	static Random rand = new Random();	
	static final int N = 1024;
	static final int repeat = 1000;		
public static void main (String args[])     {
int a[] = new int[N];
long time, time_end, time1000ex=0;

for(int k=0; k<repeat; k++)
{
	for(int i = 0; i < a.length;  i++) 
          a[i] = rand.nextInt(Integer.MAX_VALUE);
time =System.nanoTime();
    sortRiseUpBubble(a);
time_end=System.nanoTime();
time1000ex += (time_end - time);
}
System.out.printf("average time BUBBLE without verification: in ms: ");
System.out.printf("%.3f\n",((double)(time1000ex)/1000000.)/repeat);
time1000ex=0;
for(int k=0; k<repeat; k++)
{
	for(int i = 0; i < a.length;  i++) 
          a[i] = rand.nextInt(Integer.MAX_VALUE);
time =System.nanoTime();
    sortDecresSeq(a);;
time_end=System.nanoTime();
time1000ex += (time_end - time);
}
System.out.printf("average time SEQUENTIAL: in ms: ");
System.out.printf("%.3f\n",((double)(time1000ex)/1000000.)/repeat);

}

public static void comparar_trocar(int a[], int indice1, int indice2)   {
     if (a[indice1] < a[indice2])
     {   int tmp = a[indice1]; 
		 a[indice1] = a[indice2];
		 a[indice2] = tmp; }
 }
 
public static boolean comparar_trocarR(int a[], int indice1, int indice2)   {
     if (a[indice1] < a[indice2])
     {   int tmp = a[indice1]; 
		 a[indice1] = a[indice2];
		 a[indice2] = tmp; 
		 return true;     }
     return false;
 }
		
public static void sortRiseUpBubble(int[] num_array) { 
  for(int bubble = 1; bubble < num_array.length; bubble++)
    for(int i = 0;i < num_array.length-bubble;i++)
          comparar_trocar(num_array,i,i+1);
 }
 
 public static void sortDecresSeq(int[] num_array) {
  for(int i = 0;i < num_array.length-1;i++) 
     for(int j = i + 1;j < num_array.length;j++)
          comparar_trocar(num_array,   i,    j);
 }
 
}
