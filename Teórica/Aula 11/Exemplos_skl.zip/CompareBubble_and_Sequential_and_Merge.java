import java.util.*;
public class CompareBubble_and_Sequential_and_Merge {	
	static Random rand = new Random();	
	static final int N = 1024*4;
	static final int repeat = 1000;	
	static final int nWords = 1;	
public static void main (String args[])     {
int a[] = new int[N];
long time, time_end, time1000ex=0;
int mergeSize = (int)Math.pow(2,nWords);
for(int k=0; k<repeat; k++)
{
	for(int i = 0; i < a.length;  i++) 
          a[i] = rand.nextInt(Integer.MAX_VALUE);
time =System.nanoTime();
    sortRiseUpBubble(a);
time_end=System.nanoTime();
time1000ex += (time_end - time);
}
System.out.printf("average time BUBBLE without verification: in ms: ");
System.out.printf("%.3f\n",((double)(time1000ex)/1000000.)/repeat);
time1000ex=0;
for(int k=0; k<repeat; k++)
{
	for(int i = 0; i < a.length;  i++) 
          a[i] = rand.nextInt(Integer.MAX_VALUE);
time =System.nanoTime();
    sortDecresSeq(a);
time_end=System.nanoTime();
time1000ex += (time_end - time);
}
System.out.printf("average time SEQUENTIAL: in ms: ");
System.out.printf("%.3f\n",((double)(time1000ex)/1000000.)/repeat);

time1000ex=0;
for(int k=0; k<repeat; k++)
{
	for(int i = 0; i < a.length;  i++) 
          a[i] = rand.nextInt(Integer.MAX_VALUE);
time =System.nanoTime();
    merge_final(a, mergeSize);
 //   verifyRiseUp(a);                  // the results may be verified if required. NOTE that only sorted order is tested. For students only, i.e. do not use such verification for being sure that the results are 100% correct
 //   if (!verifyRiseUp(a)) System.out.println("The results are wrong");   // For understanding the reason abobe please see my class 11 slides
 //	else System.out.println("The results are probably correct");
time_end=System.nanoTime();
time1000ex += (time_end - time);
}
System.out.printf("average time MERGE: in ms: ");
System.out.printf("%.3f\n",((double)(time1000ex)/1000000.)/repeat);

}

public static void comparar_trocar(int a[], int indice1, int indice2)   {
     if (a[indice1] < a[indice2])
     {   int tmp = a[indice1]; 
		 a[indice1] = a[indice2];
		 a[indice2] = tmp; }
 }
 
public static boolean comparar_trocarR(int a[], int indice1, int indice2)   {
     if (a[indice1] < a[indice2])
     {   int tmp = a[indice1]; 
		 a[indice1] = a[indice2];
		 a[indice2] = tmp; 
		 return true;     }
     return false;
 }
		
public static void sortRiseUpBubble(int[] num_array) { 
  for(int bubble = 1; bubble < num_array.length; bubble++)
    for(int i = 0;i < num_array.length-bubble;i++)
          comparar_trocar(num_array,i,i+1);
 }
 
 public static void sortDecresSeq(int[] num_array) {
  for(int i = 0;i < num_array.length-1;i++) 
     for(int j = i + 1;j < num_array.length;j++)
          comparar_trocar(num_array,   i,    j);
 }
 
 public static void merge_final(int a[], int mergeSize)
{
for (int i = nWords; i < nWords *  N; i *= 2) 		
        for (int j = 0; j < nWords *  N; j += i * 2) 	
        {	if ((nWords *  N - j) > 2 * i) mergeSize = 2 * i;
         	else if ((nWords *  N - j) > i) mergeSize = nWords *  N - j;
         	else	continue;
         	merge(a, j, i, mergeSize);  // a - set of unsorted data items to merge; j - index to begin; i - index in the middle
        }
	}

public static void merge(int vec[], int beg, int mid, int vecSize) 
{  int i=0, j=mid, k=0;
   int tmp[] = new int[vecSize];
   while (i < mid && j < vecSize) 
   	if (vec[i+beg] >= vec[j+beg]) tmp[k++] = vec[beg+i++];
	else 		                  tmp[k++] = vec[beg+j++];		
   if (i == mid) 
		for(int l = k; l < vecSize; l++) tmp[l] = vec[l+beg]; 
   else 
        for(int l = k; l < vecSize; l++) tmp[l] = vec[l-mid+beg]; 
   for(int ii = 0; ii < vecSize; ii++)
           vec[ii+beg] = tmp[ii];
}

public static boolean verifyRiseUp(int array[])
{    for(int i = 0; i < array.length-1; i++)
	    if (array[i] < array[i+1]) return false;
	 return true;
}
 }
