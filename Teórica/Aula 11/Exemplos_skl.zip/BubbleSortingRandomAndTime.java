import java.util.*;
public class BubbleSortingRandomAndTime {	
	static Random rand = new Random();	
	static final int N = 64;		
public static void main (String args[])     {
    int a[] = new int[N];   
    for(int i = 0; i < a.length;  i++) 
          a[i] = rand.nextInt(1000);
    String dao = "dados nao ordenados", dor = "dados ordenados";
    System.out.println(dao);
    print(a);
long time=System.nanoTime();
//      sortRiseUpBubble(a);
        sortRiseUpBubbleAlternative(a);
long time_end=System.nanoTime();
	if (!verifyRiseUp(a)) System.out.println("The results are wrong");
	else System.out.println("The results are probably correct");
    System.out.println(dor);
    print(a);
System.out.printf("measured time (in ns): %d\n",time_end-time);
System.out.printf("measured time (in ms): %.3f\n",(double)(time_end-time)/1000000.);
}

public static void sortRiseDown(int[] num_array) {
  for(int i = 0;i < num_array.length-1;i++) 
     for(int j = i + 1;j < num_array.length;j++)
          comparar_trocar(num_array,i,j);
 }
 
 public static void sortRiseUpBubble(int[] num_array) { 
  for(int bubble = 1; bubble < num_array.length; bubble++)
    for(int i = 0;i < num_array.length-bubble;i++)
          comparar_trocar(num_array,i,i+1);
 }
 
 public static void sortRiseUpBubbleAlternative(int[] num_array) { 
  boolean trocas;
  for(int bubble = 1; bubble < num_array.length; bubble++)
  { trocas = false;
    for(int i = 0;i < num_array.length-bubble;i++)
          if( comparar_trocarR(num_array,i,i+1) ) trocas = true;
    if(trocas == false) break;
  }
 }
 
 public static void comparar_trocar(int a[], int indice1, int indice2)   {
     if (a[indice1] < a[indice2])
     {   int tmp = a[indice1]; 
		 a[indice1] = a[indice2];
		 a[indice2] = tmp; }
 }
 
public static boolean comparar_trocarR(int a[], int indice1, int indice2)   {
     if (a[indice1] < a[indice2])
     {   int tmp = a[indice1]; 
		 a[indice1] = a[indice2];
		 a[indice2] = tmp; 
		 return true;     }
     return false;
 }

public static void print(int array[])
{    for(int i = 0; i < array.length; i++)
		System.out.printf("array[%d] = %d;\n",i,array[i]);     }

public static boolean verifyRiseDown(int array[])
{    for(int i = 0; i < array.length-1; i++)
	    if (array[i] > array[i+1]) return false;
	 return true;
}
public static boolean verifyRiseUp(int array[])
{    for(int i = 0; i < array.length-1; i++)
	    if (array[i] < array[i+1]) return false;
	 return true;
}

}
