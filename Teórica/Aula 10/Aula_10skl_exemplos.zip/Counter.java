import java.util.*;                                       
public class Counter {
  static Scanner read = new Scanner(System.in);
public static void main (String args[])  throws   InterruptedException     {
   System.out.print("Valor inicial  ?  ");
   int ii = read.nextInt(16);
   System.out.print("inc - 1 ");
   boolean inc = (read.nextInt() == 1) ? true:false;
   String s = Integer.toString(ii,2);
   System.out.printf("Codigo binario de inteiro %d  =  %s\n\n",ii,s);
   for(int i = 0; i<32; i++) {
       Thread.sleep(750);
		   s = Integer.toString(inc==true?++ii:--ii,2);
		   for(int k=0; k<70; k++) 
		     System.out.printf("\b"); 
		   for(int a=0; a<32-s.length(); a++)
		          System.out.print("0");
           System.out.print(s+"       integer = "+ii+"        "); 
           if(ii == 0) break;       } 
	System.out.println();
}
}



