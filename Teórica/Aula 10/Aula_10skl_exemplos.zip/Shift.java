import java.util.*;                                       
public class Shift {
  static Scanner read = new Scanner(System.in);
public static void main (String args[])   throws   InterruptedException    {
   System.out.print("Inteiro  ?  ");
   int ii = read.nextInt(16);
   String s = Integer.toString(ii,2);
   System.out.printf("Codigo binario de inteiro %d  =  %s\n\n",ii,s);
   for(int i = 0; i<32;i++) {
       Thread.sleep(1000);
		   s = Integer.toString((ii=ii>>1),2);
		   for(int k=0; k<70; k++) 
		     System.out.printf("\b"); 
		   for(int a=0; a<32-s.length(); a++)
		          System.out.print("0");
           System.out.print(s+"       integer = "+ii+"        "); 
           if(ii == 0) break;       } 
		   System.out.println();
}
}



