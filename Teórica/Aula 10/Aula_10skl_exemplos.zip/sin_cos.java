import java.util.*;                                       
public class sin_cos {
  static Scanner read = new Scanner(System.in);
public static void main (String args[])       {
  double si[] = new double[314];
  for(int i = 0; i<314; i++)
       si[i] = Math.cos((double)i/10.);
  for(double i = -1.; i<=1.; i+=0.1)    {
      for(int j = 1; j<80; j++)
          if(Math.abs(i-si[j]) < 0.1 ) System.out.print("*"); else System.out.print(" ");
      System.out.println();
						                 }  			
}                                                           
}
