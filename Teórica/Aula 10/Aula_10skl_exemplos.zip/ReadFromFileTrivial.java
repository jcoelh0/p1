import java.util.*;
import java.io.*;

public class ReadFromFileTrivial
{      static Scanner kb = new Scanner(System.in);
 public static void main(String[] args) throws IOException, InterruptedException
 {   String name_of_file;
	 System.out.print("Nome do fisheiro: ");    // to_use_sorted_result.txt
     name_of_file = kb.nextLine(); 
     File my_file = new File(name_of_file);
     Scanner read_from_file = new  Scanner(my_file);
     while(read_from_file.hasNext())
     { Thread.sleep(100);
       System.out.println(read_from_file.next());  }
     read_from_file.close();
   }
}  
