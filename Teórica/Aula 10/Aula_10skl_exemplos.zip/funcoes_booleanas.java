import java.util.*;
import java.io.*;                                  
public class funcoes_booleanas
{
 public static void main(String[] args)   throws IOException
 {      int a[] = { 0, 1, 2, 3 };
File fout = new File("for_boolean.txt");
PrintWriter pw = new PrintWriter(fout);
        pw.println("opera��o ^ :");
             for (int i = 0; i < a.length; i++)
               {   pw.print(((a[i] & 0x2)>>1) + "   " + (a[i] & 0x1) + "   " + (((a[i] & 0x2)>>1) ^ (a[i] & 0x1)) + '\n');
				   pw.println();     }   pw.println();
        pw.println("opera��o | :");
             for (int i = 0; i < a.length; i++)
               {   pw.print(((a[i] & 0x2)>>1) + "   " + (a[i] & 0x1) + "   " + (((a[i] & 0x2)>>1) | (a[i] & 0x1)) + '\n');
                   pw.println();     }   pw.println();
        pw.println("opera��o & :");
             for (int i = 0; i < a.length; i++)
               {    pw.print(((a[i] & 0x2)>>1) + "   " + (a[i] & 0x1) + "   " + (((a[i] & 0x2)>>1) & (a[i] & 0x1)) + '\n');
				    pw.println();     }
pw.close();
}
}
