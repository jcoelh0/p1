import java.util.*;     
import java.io.*;                                  
public class sin_cos_to_file {
  static Scanner read = new Scanner(System.in);
public static void main (String args[])  throws IOException     {
  double si[] = new double[314];
  for(int i = 0; i<314; i++)
       si[i] = Math.cos((double)i/10.);
       
File fout = new File("to_write_graphic.txt");
PrintWriter pw = new PrintWriter(fout);
  
  for(double i = -1.; i<=1.; i+=0.1)    {
      for(int j = 1; j<80; j++)
          if(Math.abs(i-si[j]) < 0.1 ) {  System.out.print("*"); pw.print("*");  }
          else                         {  System.out.print(" "); pw.print(" ");  }
      System.out.println();  pw.println();                  }  
pw.close();
}       }
