import java.util.*;                                   
public class triks {
  static Scanner read = new Scanner(System.in);
public static void main (String args[]) throws   InterruptedException    {
   for(int i = 0; i<20;i++)
       { Thread.sleep(500); System.out.print("*"); } 
   for(int i = 0; i<20;i++) 
       { Thread.sleep(500); System.out.printf("\b \b"); }
}
}
